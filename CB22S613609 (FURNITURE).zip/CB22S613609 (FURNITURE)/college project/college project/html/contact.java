document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('contactForm');

  // Function to validate name
  function validateName() {
    const name = document.getElementById('name');
    const nameError = document.getElementById('nameError');
    if (name.value.trim() === '') {
      nameError.textContent = 'Name is required';
      return false;
    } else {
      nameError.textContent = '';
      return true;
    }
  }

  // Function to validate email
  function validateEmail() {
    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    if (!emailPattern.test(email.value)) {
      emailError.textContent = 'Please enter a valid email';
      return false;
    } else {
      emailError.textContent = '';
      return true;
    }
  }

  // Function to validate phone
  function validatePhone() {
    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phoneError');
    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(phone.value)) {
      phoneError.textContent = 'Please enter a valid 10-digit phone number ';
      return false;
    } else {
      phoneError.textContent = '';
      return true;
    }
  }

  // Function to validate message
  function validateMessage() {
    const message = document.getElementById('message');
    const messageError = document.getElementById('messageError');
    if (message.value.trim() === '') {
      messageError.textContent = 'Message is required';
      return false;
    } else {
      messageError.textContent = '';
      return true;
    }
  }

  // Event listeners for real-time validation
  document.getElementById('name').addEventListener('input', validateName);
  document.getElementById('email').addEventListener('input', validateEmail);
  document.getElementById('phone').addEventListener('input', validatePhone);
  document.getElementById('message').addEventListener('input', validateMessage);

  // Final form submission validation
  form.addEventListener('submit', function (event) {
    const isValidName = validateName();
    const isValidEmail = validateEmail();
    const isValidPhone = validatePhone();
    const isValidMessage = validateMessage();

    if (!isValidName || !isValidEmail || !isValidPhone || !isValidMessage) {
      event.preventDefault();
    }
  });
});
