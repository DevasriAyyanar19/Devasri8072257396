<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Validation checks
    $errors = [];

    if (empty($name)) {
        $errors['name'] = "Name is required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format.";
    }

    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors['phone'] = "Invalid phone number.";
    }

    if (empty($message)) {
        $errors['message'] = "Message is required.";
    }

    // If no errors, send the email
    if (empty($errors)) {
        $to = "devasriayyanar05@gmail.com";
        $from = "cb22s613609@vcsm.ac.in";
        $subject = "New Contact Us Message";
        $body = "Name: $name\nEmail: $email\nPhone: $phone\nMessage:\n$message";
        $headers = "From: $email";

        if (mail($to, $subject, $body, $headers)) {
            echo "Thank you for contacting us!";
            // Send WhatsApp message
            $whatsappUrl = "https://api.whatsapp.com/send?phone=8072257396&text=thank you" . urlencode($body);
            header("Location: $whatsappUrl");
            exit();
        } else {
            echo "Sorry, there was an error sending your message. Please try again later.";
        }
    } else {
        // Display errors
        foreach ($errors as $field => $error) {
            echo "<p>$field: $error</p>";
        }
    }
}
?>
